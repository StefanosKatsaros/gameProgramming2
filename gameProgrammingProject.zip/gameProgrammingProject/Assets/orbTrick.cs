﻿using UnityEngine;
using System.Collections;

public class orbTrick : MonoBehaviour {


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnCollisionEnter (Collision col)
	{
		GameObject.Find("templateEnaN").GetComponent<rotateAround>().action = true;
		GameObject.Find("templateDioN").GetComponent<rotateAround>().action = true;
		GameObject.Find("templateTriaN").GetComponent<rotateAround>().action = true;


	}
}
