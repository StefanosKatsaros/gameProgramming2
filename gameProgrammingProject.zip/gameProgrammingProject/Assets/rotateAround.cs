﻿using UnityEngine;
using System.Collections;

public class rotateAround : MonoBehaviour {



	public Transform templateEnaPosition;
	public GameObject enaA;
	public GameObject enaB;
	public GameObject enaC;
	public GameObject enaD;
	public GameObject triggerEna;
	public GameObject callGameController;

	public Light lt1;



	public bool action = false;

	public bool initiated = false;

	public float timer = 10.0f;
	public float x = 10.0f;
	float y = 20.0f;



	void Update () {

		enaA.transform.RotateAround (templateEnaPosition.position, Vector3.up, x * Time.deltaTime);
		enaB.transform.RotateAround (templateEnaPosition.position, Vector3.up, x * Time.deltaTime);
		enaC.transform.RotateAround (templateEnaPosition.position, Vector3.up, x * Time.deltaTime);
		enaD.transform.RotateAround (templateEnaPosition.position, Vector3.up, x * Time.deltaTime);


		// if user pulls lewer
		if (action == true) {



			triggerEna.GetComponent<Collider>().enabled = false;
			initiated = true;
			timer = Random.Range(10.0f, 22.0f);

		 	callGameController.GetComponent<winCondition>().Az = 0;
			callGameController.GetComponent<winCondition>().Bz = 0;
			callGameController.GetComponent<winCondition>().Cz = 0;
			callGameController.GetComponent<winCondition>().Dz = 0;

			lt1.color = Color.white;
			action = false;

		}


		// when lewer has been pulled the magic objects speed up and the countdown begins
		if (initiated == true) {
			if(x < 250.0f){
				x = x + y *Time.deltaTime;
			}
			timer -= Time.deltaTime;
		}

		// when timer becomes 0 the collider will be activated and whichever one of the magic objects strikes it they will stop
		if (timer <= 0.0f) {
			triggerEna.GetComponent<Collider>().enabled = true;
			initiated = false;

		}
	}
}
