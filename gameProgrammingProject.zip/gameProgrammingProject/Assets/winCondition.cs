﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class winCondition : MonoBehaviour {

	public int Az = 0;
	public int Bz = 0;
	public int Cz = 0;
	public int Dz = 0;
	public GameObject magicMonkeyGift;
	public GameObject magicMonkeyGiftInstPosition;
	public GameObject introObject;

	public static int score;
	public Text text;  

	private float countdown = 7 ;

	void Start(){
		//text = GetComponent <Text> ();
		score = 0;


	}

	void Update () {

		countdown -= Time.deltaTime;
		if (countdown <=0) {
			Destroy(introObject);
		}
		// could have them all in one if statement, but maybee we could do something different for each condition

		if(Az == 3){
			Debug.Log ("Victory for A");
			Instantiate (magicMonkeyGift,magicMonkeyGiftInstPosition.transform.position,magicMonkeyGiftInstPosition.transform.rotation);
			Az = 0;
			score++;
		}
		if(Bz == 3){
			Debug.Log ("Victory for B");
			Instantiate (magicMonkeyGift,magicMonkeyGiftInstPosition.transform.position,magicMonkeyGiftInstPosition.transform.rotation);
			Bz = 0;
			score++;
		}
		if(Cz == 3){
			Debug.Log ("Victory for C");
			Instantiate (magicMonkeyGift,magicMonkeyGiftInstPosition.transform.position,magicMonkeyGiftInstPosition.transform.rotation);
			Cz = 0;
			score++;
		}
		if(Dz == 3){
			Debug.Log ("Victory for D");
			Instantiate (magicMonkeyGift,magicMonkeyGiftInstPosition.transform.position,magicMonkeyGiftInstPosition.transform.rotation);
			Dz = 0;
			score++;
		}
		text.text = "Score: " + score;
	}
}