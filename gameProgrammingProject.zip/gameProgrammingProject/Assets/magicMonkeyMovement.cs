﻿using UnityEngine;
using System.Collections;

public class magicMonkeyMovement : MonoBehaviour {


	public GameObject magicMonkeyGift;
	public GameObject magicMonkeyGiftInstPosition;

	public GameObject scriptAccessor;
	public GameObject scriptAccessor2;
	public GameObject scriptAccessor3;

	public Transform RootObject;
	public Transform RootObjectRotation;

	private Vector3 point;

	void Start(){
		point = RootObjectRotation.transform.position;
	}

	void Update() {

		//transform.RotateAround (RootObject, new Vector3 (0.0f, 1.0f, 0.0f), 20 * Time.deltaTime);
		transform.RotateAround(point, Vector3.up, 10 * Time.deltaTime);
		transform.LookAt (RootObject);

		if(scriptAccessor.GetComponent<rotateAround>().initiated == true && scriptAccessor2.GetComponent<rotateAround>().initiated == true && scriptAccessor3.GetComponent<rotateAround>().initiated == true){
			gameObject.GetComponent<MeshRenderer>().enabled = true;
		}else {
		gameObject.GetComponent<MeshRenderer>().enabled = false;
		}
	}

	void OnCollisionEnter(Collision col){
		Destroy(gameObject);
		Instantiate (magicMonkeyGift,magicMonkeyGiftInstPosition.transform.position,magicMonkeyGiftInstPosition.transform.rotation);
		Instantiate (magicMonkeyGift,magicMonkeyGiftInstPosition.transform.position,magicMonkeyGiftInstPosition.transform.rotation);
		Instantiate (magicMonkeyGift,magicMonkeyGiftInstPosition.transform.position,magicMonkeyGiftInstPosition.transform.rotation);
		winCondition.score += 3;
	}
}