﻿using UnityEngine;
using System.Collections;

public class collisionDetector : MonoBehaviour {

	public GameObject callTemplateEna;
	public GameObject callGameController;

	public Light lt;

	void start(){
		lt = GetComponent<Light>();
	}

	void OnTriggerEnter(Collider col)
	{	
		// depending on the magic object that collides, we will add +1 to the win condition

		if (col.gameObject.name == "enaA" || col.gameObject.name == "dioA" || col.gameObject.name == "triaA" )
		{
			callGameController.GetComponent<winCondition>().Az++;
			lt.color = Color.red;
		}

		if (col.gameObject.name == "enaB" || col.gameObject.name == "dioB" || col.gameObject.name == "triaB")
		{
			callGameController.GetComponent<winCondition>().Bz++;
			lt.color = Color.green;
		}

		if (col.gameObject.name == "enaC" || col.gameObject.name == "dioC" || col.gameObject.name == "triaC")
		{
			callGameController.GetComponent<winCondition>().Cz++;
			lt.color = Color.blue;
		}

		if (col.gameObject.name == "enaD" || col.gameObject.name == "dioD" || col.gameObject.name == "triaD")
		{
			callGameController.GetComponent<winCondition>().Dz++;
			lt.color = Color.magenta;
		}


		// will stop magic objects from moving around

		callTemplateEna.GetComponent<rotateAround>().x = 0.0f;
	}
}
